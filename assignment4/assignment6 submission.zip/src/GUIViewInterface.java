/**
 * A ViewInterface for all GUI-related functionality. Objects of this type should be used whenever
 * the GUI is involved.
 */
public interface GUIViewInterface extends ViewInterface {
}
